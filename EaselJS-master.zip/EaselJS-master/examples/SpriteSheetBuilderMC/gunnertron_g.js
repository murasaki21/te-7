(function (lib, img, cjs) {

var p; // shortcut to reference prototypes
var rect; // used to reference frame bounds

// stage content:
(lib.gunnertron_g = function() {
	this.initialize();

	// gunnertron
	this.instance = new lib.gunnertron();
	this.instance.setTransform(262.1,326.3);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(151.5,250.7,224,212.1);
p.frameBounds = [rect];


// symbols:
(lib.shoulder = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#14263F").s().p("AA2geQgBgIgGgFQgGgGgHAEQgGAEgFAOQgIAOgDAGQgFAHgHACQgEACgOAAQgFAAgLgFQgJgHgGADIgBAAQgFACgBAGQgBARAWAQQAUAPAagFQAWgEARgYQALgQgHggIAAAA").cp();
	this.shape.setTransform(4.9,4.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,85,85,0.467)").s().p("ABAAGQgKgQgXgIQgTgHgVAEQgZAEgSAMQgGAEgCAFQgCAEgBAKQgBAFAFAAQAFABACgFQAHgSAmgBQANgBAUADQALADAXAHQACAAABgCQACgCgBgCIAAAA").cp();
	this.shape_1.setTransform(-2.1,-6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAyAYQgLABgFAAQgXAAgdgVQgbgRgMgTQgBAAgBAAQgBAAAAAGQAAAVAkATQAeATAWAAQAPAAASgKQgCgBgJACIAAAA").cp();
	this.shape_2.setTransform(-0.1,-1.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAfg5QgWgMgDAAQgNgFghAAQg4AAAAA0QAAArA2AeQAqAYAjAAQA+AAAAgnQAAgXgRgRQgagegCgCIgBgBIAAgCQgBAAAAAGQAAACAQAeQAQAcAAAEQAAARgPAGQgJADgWAAQgzAAgjgkQgcgaAAgWQAAgaAdgBQATAAA8gCIABgB").cp();
	this.shape_3.setTransform(-0.7,-1.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B51C2E").s().p("AgphCQgsgBgDApQgDAkAyAgQAtAdApgEQAeAAAKgRQAKgRgPgaIgSgVQgMgNAAgJIgUgUQgugJgZgBIAAAA").cp();
	this.shape_4.setTransform(-0.6,-1.8);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-10.5,-9.3,21.2,18.8);
p.frameBounds = [rect];


(lib.innerringmove = function() {
	this.initialize();

	// Layer 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,85,85,0.467)").s().p("AA/APQgIgKgPgFQgJgEgSgEQgWgGgNgCQgWgFgPADQgDABAAACQAAADADABQBqAbAMAEQACABABgCQACgCgBgCIAAAA").cp();
	this.shape_5.setTransform(11.2,-3.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,85,85,0.467)").s().p("AAcgCQgFgEgGgBQgCAAgMAAIgOACQgKADgGABQgCABAAAAQAAABACABQAFABAJACQAIACAFAAQANABACAAQAIgBAFgEQACgBAAgCQAAgBgCgBIAAAA").cp();
	this.shape_6.setTransform(-0.3,6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,85,85,0.467)").s().p("ABoAkQgogIgPgEQgegIgVgKQgQgGgfgTQgegTgSgHQgFgBgCAFQgDAFAEADQBqBfBlgSQADgBAAgDQAAgDgDgBIAAAA").cp();
	this.shape_7.setTransform(-14.3,0.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,85,85,0.467)").s().p("ADLAtQgWgfg2gPQgHgChTgSQhNgRgpgGQhDgIg1AGQgCACABAAQAmAFBJALQA/AKAtAMQANADAfAFQAcAGAQAEQASAFAeANQAgAPAOAEQACABACgCQABgCgBgBIAAAA").cp();
	this.shape_8.setTransform(2.5,-3.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,85,85,0.467)").s().p("AD/AxQh1AIiggZQiYgXhLhVQgCgDgEACQgDACABAEQAFASAVAXQARATATALQAeAVAqAOQAeAKAwAJQBlAVAzADQBZAFA9gcQACgBgBgDQAAgCgDAAIAAAA").cp();
	this.shape_9.setTransform(-1.6,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FA3C24").s().p("ADrAeQglgajWgkQi4gfgwgCQgDgHAAAKQAAANA1AWQA1AWBLAQQC+AwBrgbQAAgDAIABIAAAAAD/BVQgnAOhkAAQhtAAiBgmQipgyAAhLQAAgOAMgKQAOgKAbAAQAtAABfAQQA2AIBnASQAHABBzAQQBvAbAAA1QAAAfglANIAAAA").cp();
	this.shape_10.setTransform(0,0.1);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-29.1,-9.8,58.5,19.9);
p.frameBounds = [rect];


(lib.hand = function() {
	this.initialize();

	// Layer 1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#14263F").s().p("ABJAkQgHgPgEgIQgGgNgIgGQgMgVgOgQQgIgIgNgBQgNgIgQAJQgFADgCAFIgRADQgFAAgFACQgJAEgCAIQgCAHAEAHQgBAGADAJQAEAOAAADQABAHAHAAQAGAAABgHIAAgCIAGABQAiAAAXADQAPAAACADIASAZQAIAMALgHQAMgHgGgMIAAAA").cp();
	this.shape_11.setTransform(-8.6,2.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#14263F").s().p("AAKhOQgqgggWgQQgDgCgDADQgDADACADQAJATAhAmQAbAjAJAZQAHASgBAuQAAArAKAVQABACACAAQACAAABgBQAngwgYhbQgJgkgjgeIAAAA").cp();
	this.shape_12.setTransform(5.2,-6.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,85,85,0.467)").s().p("ABKA3QgUghgJgQQgRgbgPgSQghgpgzAlQgEADACAFQACAEAFgBQAJgDATgFQAQgDALAKQAHAGAFALQAFAHAIALQAPAXAIAKQAQASAPAIQACABADgCQADgCgCgDIAAAA").cp();
	this.shape_13.setTransform(-6.6,0.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,85,85,0.467)").s().p("AA0gpQg2hmhPATQgFACgBAGQgBAGAFADQBAAfAmBDQAXAmAhBfQABAEAEAAQADAAABgEQAJgggJgvQgJgtgXgpIAAAA").cp();
	this.shape_14.setTransform(-0.5,-8.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,85,85,0.467)").s().p("ACHg4QgogPghAOQgfANgWAlQgKASgfACQgjgBgQAEQgoAKgQAfQgCADADAEQADADADgDQAZgRAyAAQA1ABAUgMQAJgEAIgMQABgCAKgRQANgUAcgJQAQgFAigIQAGgCAAgFQAAgFgGgDIAAAA").cp();
	this.shape_15.setTransform(4,11.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,85,85,0.467)").s().p("AgKh2QgOg+gIhDQgBgLgJgFQgKgEgIAIQgSASgCAhQgBAVAFAkQAQBjABAFQAGA3gIAwQgJAwADAfQADAqAWAgQASAbAgARQAkASAdgJQAHgCACgIQABgIgHgEQgtgbgQgSQgXgcgBgqQgBgXAGglQAHgzABgIQADgZgGglQgBgQgKguIAAAA").cp();
	this.shape_16.setTransform(-17,-3.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Ag5iJQA+A8AQAhQAdA4AEB+IAAAAQABgCABgQQACgQAAgHQAAhugshBQgcgvgqgMIgBAA").cp();
	this.shape_17.setTransform(2.2,-5.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgNgsQAAgVADAAQACAAACAUIATBTQABAEAAAHQAAAJgBAGIAAACIgEAAIAAgCIgCgOIgLgvQgHgZgCgWIAAAA").cp();
	this.shape_18.setTransform(-14.7,7.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B51C2E").s().p("AADARQgBgEgBgCQgLgxAAgaIANBRQABAGADAMQAEANAAAKIAAAHIgIgw").cp();
	this.shape_19.setTransform(-14.7,7.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAxgvQAhAuAAAUQAAADgHAKQgKAPgOANQgNALgQAIQACAAACgBQAxgLAAgVQARgWAAgIQAAgPgagtQgdg0gWgBQghACgmAUQgjARAAAIQAAANACAHQACgeAzgRQAagIAZgDQAEAAAeApIAAAAAhBA3IAAAqIACABQAIgCAKgDQgHAAgHgBQgEgdgBgHIgBgB").cp();
	this.shape_20.setTransform(-9.8,6.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7F1C2D").s().p("AARheQAUAHAeA8QASAfACADQAGAVgTANQgeAYgiAOQgkAQgjAAQAAgHgCgNQgBgOAAgGIgYhVIAAgYQAMgJAjgOQAXgJAGgCQAQgGANAAIAAAA").cp();
	this.shape_21.setTransform(-9.9,6.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("ABUAkQAAhIgZgxQghhChFAAQgYAAgKASQgGALAAAWQAABOANBVQAJA+AIAaIABABQABgCAAgJQAAglgGhGQgGhEAAhCQAAgTAGgHQAFgFAIAAQBEAAAhBUQARArAIA1QACgCAAgLIAAAA").cp();
	this.shape_22.setTransform(-16.5,-16.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B51C2E").s().p("ABOAsIiHBnQgJhNgEgmQgHhBABgzQgCgcACgJQADgXAUgCQAcgCAeAVQAdATAPAaQAPAYAGAmQADAUAFAsIAAAA").cp();
	this.shape_23.setTransform(-16,-15.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("Ag/hCQgWAjgFAXIABACQAfgoAPgTQAagiAVABQAVACAiA6QAfA1AAAPQAAAgggAVQgXAQgOAAQgVAAglgdQgvgjgbgKQAFADA6AxQAvAnAZAAQAjAAAZgiQAUgiADAAQAGAAgBgEQgDgKAAgBQAAgdgtg7Qgsg8gTAAQghAAgfAxIAAAA").cp();
	this.shape_24.setTransform(14.4,18.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgqhKQgYAbgSApIgQAfIgEgBQALADAUATQAcAbADACQAgAUAJAEQAZANASgHQATgEAUgVQATgUADgQQALgegsgsQgMgbgIgPQgPgbgSgGQgagIghAnIAAAA").cp();
	this.shape_25.setTransform(13.8,18.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("ABeAbQAAAUgXALQgYAHgBAAQgcAAg4ggQg4gfgMgRIgEABIgCADQApAtA0AcQAnAWAYAAQASAAAVgNQAegRAAgdQAAgdgmgnQgngogfAAQglAAgeARQgeARgEAaIACAGQAOgSAOgLQAbgUAnAAQAbAAAiAjQAhAgAAAaIAAAA").cp();
	this.shape_26.setTransform(1.2,23.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("ABTgUQgWgggOgLQgZgVg3AQQg7AQABAkIgLADQgNABAVAQQAUAQAHACQAXATAsAUQA0AYANgPQALACAQgRQARgRgCgLQgBgPgXggIAAAA").cp();
	this.shape_27.setTransform(0.8,23);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("Ag7jdQBnAABQBfQBEBRAABAQAABhhQA1QhGAuhrAAQhBAAgeggQgigkAAhSQAAizAUhOIAAgBQgLAXgLBJQgOBVAABOQAABOAbAnQAiAzBUAAQBnAABKgpQBjg4AAh2QAAhJhKhTQhVhghvAAQgeAAglAWQgcAQgLANIgBAAQALAAAogTQAogUAQAAIAAAA").cp();
	this.shape_28.setTransform(-2.9,1.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#B51C2E").s().p("AC2g2QAiBFgYBIQgZBJhJAgQjwBXgtiCQgMgoACg+QAEhDABghQADgzADgVQAGgmALgcIAIALQBRhOByA2QBqAwAuBmIAAAA").cp();
	this.shape_29.setTransform(-3,1.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AhhgZQAhA2A8AXQAcALAbAAQAdAAALgRQAHgKAAgNQAAgWgggeQgjghgfAAQgkAAgEAEQgDADgKALIgBABQACABAugHQAcAAAeAhQAbAaAAANQAAAIgHAFQgHAHgNAAQgrAAgegVQhDgrgHgEIgCAA").cp();
	this.shape_30.setTransform(-8.8,24.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AhCAAQATATAHAFQAPANASAGQAIAEAYAEQAdAFAQgCQAXgKAAgRQABgNgOgRQgXgagNgKQgXgRgWADQgDABgTADQgQAEgKAEIgrASQAKAEAQATIAAAA").cp();
	this.shape_31.setTransform(-9.3,24.5);

	this.addChild(this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-25.2,-31.4,50.9,63);
p.frameBounds = [rect];


(lib.gunforearm = function() {
	this.initialize();

	// Layer 1
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,85,85,0.467)").s().p("ABHALQgMgHgXgCQgbgCgJgCQAAAAgggNQgUgIgPgBQgFAAgBAFQgBAGAFABQAWAGAvAVQArASAcgOQADgBAAgDQAAgDgDgBIAAAA").cp();
	this.shape_32.setTransform(1.3,0.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#14263F").s().p("AA7ADQgogLgDgBQgWgIgRgKQgLgGgXgJQgGgCgFAEQgEAEgBAGQAAAUAeANQAFADAPAIQANAHAIADQACABAwARQATAGAFgTQAGgUgTgGIAAAA").cp();
	this.shape_33.setTransform(0.8,5.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AichvIgBAIQgJAeBOAkQAnASApANQAAALAaABQARABAtgBQBaABAAA5QAAARgRAJQgPAHgbAAQgQAAgxgPQg3gRgygYQg6gcgfgbQAVAWAgAaQBiBOBsAAQArAAASgRQANgLAAgPQAAgxgrgSQgYgIhLgGQhLgHglgOQg8gXgag3IgBAAAimhgQgGgDgLACIgBALQAAAHACAHQgBgLAEgLQAAgBANgBIAAAA").cp();

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#242526").s().p("AiZhsQgFA9CbAnQAcAIAjADQAWACAwAAQAkAAAJAXQAFAMAAAtQghAegygIQgWgDhBgYQhVglgkgZQhGgvADg7IAAgFIAPAAIAKgP").cp();
	this.shape_35.setTransform(-0.2,-0.3);

	this.addChild(this.shape_35,this.shape_34,this.shape_33,this.shape_32);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-18.4,-11.2,37,22.6);
p.frameBounds = [rect];


(lib.gun = function() {
	this.initialize();

	// Layer 1
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#14263F").s().p("ACOBEIgUhGQgFgSgcgLQgMgEgZAAQgaAAgLgDQgmgIgUgFQgkgIgVgNQgGgEgIADQgCgDgGgGQgGgGgIAEQgHAFACAJIAAAEQABAEADACQAVAvAKANQATAbAiAQQARAIAZAGQANADAdAFQAKACAmAKQAeAIATACQAHAAAFgGQAEgGgCgHIAAAA").cp();
	this.shape_36.setTransform(-11.7,11.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,85,85,0.467)").s().p("ABDi/QgwgSgnBGQgfA1gMBBQgQBVAiBPQAMAcAYAPQAZARAVgOQACgBAAgDQAAgDgCgBQhQhDAYiNQAIgxATgrQAZg1AigLQACgBAAgDQAAgDgCgBIAAAA").cp();
	this.shape_37.setTransform(13.7,1.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,85,85,0.467)").s().p("Ahri9QAhAEAUAIQAXAJAWAXQAdAgAPAVQAWAeAKAiQATA9giBHQgeBAgzAkQgDACACADQABAEAEgBQA/gNArhIQArhKgOhKQgRhXhAg8QhDhBhGAgQgFACABAFQAAAFAFAAIAAAA").cp();
	this.shape_38.setTransform(24.3,-2.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,85,85,0.467)").s().p("ACegqQgPgegygBQgMAAg+AIQgvAHgtAgQgKAHgMANQgGAGgMAOIgUAAQgMAAgHAKQgGAIAAANIgBAAQgJACACAMQABALAJAAIAKgBQAFAEAIABQB6AAA+gMQCUgagphOIAAAA").cp();
	this.shape_39.setTransform(-8.6,-16.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,85,85,0.467)").s().p("ADEgCQgfgSg4gBQg/ABgcgBQhFgHgmgCQhCgCgnARQgFADAAAGQAAAGAFAAQAjARA8ACQAhABBAABQAdACBHAIQA/ADAjgUQAEgCAAgHQAAgFgEgCIAAAA").cp();
	this.shape_40.setTransform(-13.6,-3.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAIhFQgBgsABAAQADAAAFAsIAAgBIAFBLQAAAbgDAVQgEAVgKAQQgFAMgKAHQgIAGgBgBQAAgBAGgHQAJgJAFgLQAGgQADgTQACgRAAgdIgDhK").cp();
	this.shape_41.setTransform(24.1,-0.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgBg6QAKAeADAcIACAPIgBAqQgCAOgCAEQgBADgCACQgBACAAgBQAAgCAAgEIgChEIgBgHQgCgUgHgkQgHgXABgBQADgBAJAXIAAAA").cp();
	this.shape_42.setTransform(27.5,-5.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgHgCQACAEACACQADADAAgCQAEgCACgDQACgEgBgDQAAgDgCgBQgCgCAAgBIADgBQAFAAADAFQADAFgCAGQgDAKgHADQgFADgEgCQgFgCgCgEQgDgFAAgFQAAgFADgEQAEgBAAACIgBACIABAF").cp();
	this.shape_43.setTransform(-31.6,-1.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AAkixQgfAZgTAwQgVAvAAAnQAAB9AXAnQAGALAJAGQALAHACAEIAIAEIgYgWQgGgFgGgSQgNglAAhNQAAhJAWgtQAbgsAMggIAAgC").cp();
	this.shape_44.setTransform(10.2,0.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#B51C2E").s().p("AgggbQgBATAAAkQAABCATAsQAGANAFAGQADAFALAHQACACAEACQADACADADIALljQgVAegKAPQgSAcgHAYQgHAYgDAdIAAAA").cp();
	this.shape_45.setTransform(10.4,0.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AjfADQADgBAbgCQAZAAAJAAQAFAABUAFQBtAHCOAAQAGAAAIgBQAFgCAQgDIAIgDQgfADgKAAIjCgGQgpgHgtgDQhZgGglASIAAAB").cp();
	this.shape_46.setTransform(-13.4,-5.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#B51C2E").s().p("AiZgGQBSAGAyABIjJAAQAAgHBFAAIAAAAADBAFQgKADgTgDQgWgEgJAAIBaAAQgFAAgJACQgKACgGAAIAAAA").cp();
	this.shape_47.setTransform(-13.5,-4.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("ACYBUQgOgDgMgdQgMgfgEgtQgpgBhigaQhlgcgVgEQABAZAFAHIAAABQgBgRAAgLQA5AhAVAGQAKAEBLAMQAqAGArACQgFAOARAmQASApARAGIADAA").cp();
	this.shape_48.setTransform(-10.9,11.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#B51C2E").s().p("AB7ApQgMghAAgaQgZAAgngFQg0gHgMgBQgmgHgbgLQgFgCgZgOQgSgMgOgCQAAAWAEAIIEdCBQgNgKgJgdIAAAA").cp();
	this.shape_49.setTransform(-11.4,11.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#000000").ss().p("AAzhgQAAgRgFgPQgIgUgPgEQgLgDgMARQgGAHgKASQgjAygNBZQgQBqA1ATQAmALAggnQAeglgEgo");
	this.shape_50.setTransform(22.1,0.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgQhxQgjAygNBZQgQBqA1ATQAmALAggnQAeglgEgoIgSiOQAAgRgFgPQgIgUgPgEQgLgDgMARQgGAHgKASIAAAA").cp();
	this.shape_51.setTransform(22.1,0.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AFVgEQAABdhHBFQhVBSibAAQi2AAh1h3QgsgsgZg0QgVgrABgeIgBgBQgBAEgCAKQgCAMAAAHQAACDDCBUQBBAcBMASQA5ANAYAAQCZAABVhRQBLhHgBhqQgBhmhHhKQhOhRh7AAQiSAAiRBJQiHBFgRBCIgBABQAEgEAlgnQAjgnAmgaQB7hTDPAAQBwAABHBFQBDBDAABjIAAAA").cp();
	this.shape_52.setTransform(0.2,0.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#B51C2E").s().p("AFeg4QAfCFhhBWQhMBFhvAOQhmANhfglQhlgrhEg4QhohWAThWIAGABQBghrB1gxQBWggBPgJQBlgLBIAaQA3AUAoAwQAmAuAOA8IAAAA").cp();
	this.shape_53.setTransform(-0.2,0);

	this.addChild(this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-36.3,-25.7,73,51.8);
p.frameBounds = [rect];


(lib.forearm = function() {
	this.initialize();

	// Layer 1
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,85,85,0.467)").s().p("AA7hXQgDgFgHABQgSADgJANQgHALgNAOIgTAXQgmArgEA3QgCAVAXAAQAYAAAAgVQABgUAKgZQADgOAPgZQAVgmAWgZQAFgFgEgGIAAAA").cp();
	this.shape_54.setTransform(-6.1,-5.4,1,1,-6.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#14263F").s().p("AAVgUQgLgHgKAHIgEACIgBABQgDABgBAAIACAAQgCAAgEABQgKACgFAJQgFAHAFAIIAEAFIABABQAHAFgGgEQAHAIANgCQAMgBALgGQAFgCADgGQADgGAAgDQgBgOgKgGIAAAA").cp();
	this.shape_55.setTransform(5.9,-18.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("ABGjWQg1AQgpAeQiDBcAAC2QAAAzAeAjQAeAjArAAQALAAANgFQALgEAAgCQAAgDARgUQASgVAAgOQAAgRgNg1QgMg1AAgGQAAiXBQgiQAVgJAkgIQAZgIAAgWQAAgJgIgHQgIgHgMAAQgJAAgMACQADABAEABQAWAAAOAQQgJARgeAHQguALgMAGQhJAkAACeQAAAZAOAxQALAyAAAGQAAAWgPAPQgQAQgaAAQgkAAgZgeQgagfAAguQAAitB3hXQAggZAwgUQAlgPAAgEQAAgBAAgCQgLADgPAFIAAAA").cp();
	this.shape_56.setTransform(0.1,0);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#242526").s().p("ABeilQAdgIANgIQAbgTgWgPQgPgKgSAEQAJAAAIAEIgfACQAHgEAHgCQgfAAg4AiQgKAGgWANQgWANgNALQgdAbgWAmQgWAkgMApQgNAogEAgQgFAoAHAkQAMAqAkAWQAnAYAlgVQAjgPgEgrQgMgzgGgUQgRg+AahbQAPgiAGgKQAOgZASgLQANgJAcgHIAAAA").cp();
	this.shape_57.setTransform(0.2,-0.2);

	this.addChild(this.shape_57,this.shape_56,this.shape_55,this.shape_54);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-15.5,-22.6,31.2,45.5);
p.frameBounds = [rect];


(lib.eyebrow1 = function() {
	this.initialize();

	// Layer 1
	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#14263F").s().p("ACMARQgWgSgtgEQgygBgXgEQg8gIhGgTQgGgBgDAEQgDAEADAFQALAZAiALQASAIAqAIQA1AKAgABQAxACAlgNQADgBABgDQABgDgCgDIAAAA").cp();
	this.shape_58.setTransform(0.2,4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,85,85,0.467)").s().p("ACOAjQgZgNgugNQg/gOgKgEQgsgTgWgIQgogOgeAEQgGAAgBAGQgBAFAGABQAgAGBrAsQBVAmA4gIQAEAAABgEQACgEgFgDIAAAA").cp();
	this.shape_59.setTransform(-0.1,-2.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("ACXAkQAAgZhFgUQgYgHhygdQBHAgBZAcQAMAFAOADQAIAFgBAYQhagHgvgKQg/gQhHgPQgFABgCAAQAWAGBXAaQBcAYBZAHQACgWAAgKIAAAAAiUhCQgCABAAAFQAAAHACAXQABAVABAGIAAAAQADgIABgrQgBgBAAgBQAAgCAGAAQASAAANABQgTgFgVgFQAAABgCAAIAAAA").cp();
	this.shape_60.setTransform(0,-1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#242526").s().p("ACPA+QhMAAhSgZIgngGQgYgDgMgGQgPgGgIgDQgOgGgNAAIgFgIIAAg3IAFAAIAAgFQAgAAAmAMQAWAHArAQQBEAUAjANQAFADASAEQAQAEAGAJQADAGgBAMQAAAGgCALIAAAA").cp();
	this.shape_61.setTransform(0,-1.2);

	this.addChild(this.shape_61,this.shape_60,this.shape_59,this.shape_58);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-15.1,-7.9,30.4,15.9);
p.frameBounds = [rect];


(lib.eyebrow2 = function() {
	this.initialize();

	// Layer 1
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#14263F").s().p("AAvgtQgNgBgQAPQgSASgFAGQgHAHgPAJQgGAFgEABQgCABgJABQgIABgBAJQAAAJAGAEQAOAKAQgGQAFgCAWgPQA8glgKgcQgDgGgGgBIAAAA").cp();
	this.shape_62.setTransform(0,2.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,85,85,0.467)").s().p("AAmgpQgMgJgPAPQgIAHgKARQgHAJgRAMQgMAOADAQQABAGAGgBQAFgBABgFQABgLANgKQAIgGAMgKQAGgEAKgNQACgCAHgFQAFgEACgDQAGgHgHgFIAAAA").cp();
	this.shape_63.setTransform(-0.8,-1.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AAdg8QgSADgZAWQgkAcAAAeQAAAKAAgCIABAAQAEgKAZgaQAYgcAOgKIAVAZQg6A3gDACQgLALgJABQgLgOAAgKIgBgBQgEADAAAKQAAAWAQAAQAKAAAJgKQAbgbA3goQgEgHgMgQQgMgPgCgGIAAAA").cp();
	this.shape_64.setTransform(0.2,-1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#242526").s().p("AAKgtQgOALgCABQgQAMgLARQgNAQAAASIgFgFQgDAcAPABQANABAUgUQAIgKAUgSQAUgPAKgKQgBgDgNgNQgLgKAAgJQgGAAgLAIIAAAA").cp();
	this.shape_65.setTransform(-0.1,-0.8);

	this.addChild(this.shape_65,this.shape_64,this.shape_63,this.shape_62);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-5.9,-7.1,12,14.4);
p.frameBounds = [rect];


(lib.butt = function() {
	this.initialize();

	// Layer 1
	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#14263F").s().p("ADLg9QgPgRgagHQgTgEgeAAQhXACg9AIQhBAJgxAVQgjACgYAdQgSAVAGAZQAHAYAbALQALAFAPABQADACAIACQAHACAVAHQARAFALABQAOACAWgBIAjgBQBLgBA6gQQA5gPAggfQArgngogvIAAAA").cp();
	this.shape_66.setTransform(2.3,-10.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,85,85,0.467)").s().p("ADqgpQhOAegoALQhCAVg2ADQgmACgagEQgggFgbgPQgWgLgcgcQgigjgMgKQgHgFgIAEQgJAEADAJQAZBDA4ApQA4AqBHAFQBTAGBIgbQBTgeAqg/QADgEgEgFQgEgFgFACIAAAA").cp();
	this.shape_67.setTransform(-2.4,11.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,85,85,0.467)").s().p("AAbhFQgRgIgHAQQgOAjgcBbQgBAEAEADQAEACADgDQAvguAVhHQAFgQgRgHIAAAA").cp();
	this.shape_68.setTransform(-23.2,-6.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,85,85,0.467)").s().p("AEChlQgEAIgHASQgGARgFAJQgUAog5AgQgMAHgVAHQgWAHgLAEQgHACgbAMQgUAKgOADQg+APhogXQg1gMgkgkQgRgQgRgEQgDgBgBACQgBACACABQAMAIASAVQAUAXAKAIQAXAQA0ANQAsALAuABQAuACApgKQAQgEAZgMQAegOALgEQAqgPAcgUQBHgxABhLQAAgFgEgBQgFgCgCAEIAAAA").cp();
	this.shape_69.setTransform(0,-0.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AADgMQACAIAAAEQgCADgDAAIgEgDIgBAAQAFgEAAgBQAAgCgMgBIgBAHQALAOADAAQAKAAgDgCQADgCABgBQACgCAAgGQAAgEgBgDQgCgCgBgDIgGAAIgBAA").cp();
	this.shape_70.setTransform(-16.3,1.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgEiMQgkAkgXAoQgQAfAAAKQAABYBNAvQAlAXApAGIAEAAQgugLgigWQhFgtAAhVQAAgCBBhzIAAgB").cp();
	this.shape_71.setTransform(-14.1,5.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AD2hMQgiAqgtAiQhZBChbAAQhQAAgvgKQhNgRgcgtQAGAdA2AZQA+AdBfAAQBxAABahJQA0gpATglIAAgC").cp();
	this.shape_72.setTransform(0,0.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgpixQgYAJg9AfQAbgLBNgkQgJADgKAEIAAAAAgIi9IBSgBQBrAAAyAtQAkAgAAAvQAABdhmBRQhgBOheAAQh/AAhEg9QgygtAAg3QAAgeAUg1QAXg+AkgvQgWAMghA8QgmBFAAAzQAABAA2AyQBGBCCHAAQB2AABjhgQBdhZAAhZQAAg9g3glQg4glhjAAQgmAAgtAPIAAAA").cp();

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#B51C2E").s().p("AAUjBQhQAJhCAwIhBgeQgVAWgRAiQgJATgSAoQghBBAUA6QAUA4BEAiQBSAnBXgEQBagFBFg3QBehGAdhfQAihyh6giQhUgbhOAKIAAAA").cp();

	this.addChild(this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-28.5,-20.5,57.2,41.2);
p.frameBounds = [rect];


(lib.body = function() {
	this.initialize();

	// Layer 1
	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#14263F").s().p("ABWAmQgsBDgrAAQhFAAgjhFQgXgrAAgqQAAgLAJgGQAHgEAHAAQAKAABVAIQACAAAkgLQAogLAKgEQAIgDAXgLQAUgGAAARQAABBgrBAIAAAA").cp();
	this.shape_75.setTransform(18.2,14.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,85,85,0.467)").s().p("AA4gaQgBgFgFgDQgFgCgGABQgKACgRAOQgPAOgLADQgQABgKABQgQABgBAMQAAACACABQACACADgBQADgBAHACQAEABAHABQgBAGACAFQADAFAGAAQAVAEASgOQAVgIAJgLQALgMgFgVIAAAA").cp();
	this.shape_76.setTransform(23.2,24.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#14263F").s().p("ABNBEQg4gfgagUQg3gkgdgZQgygrgRglQgCgDgDABQgCACAAACQASBABhBMQBtBZBgAUQAEABACgEQACgEgEgCQgZgRg7ghIAAAA").cp();
	this.shape_77.setTransform(-10.6,18.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#14263F").s().p("AApg1QABAXgCAnQAAAdAOAQQATAUAHAXIgMALQgIAAgKgQQgVgigWgbQgXgWgUgPQgngigEgQIACgNQABAAADgCQACgCAGAAQAFAAAEALQAEAKAHAAQADAAAggEQAJAAAHgYQAMgZAEgCQAQALADArIAAAA").cp();
	this.shape_78.setTransform(-40.8,-1.1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,85,85,0.467)").s().p("AAWhiQgEgSgQgeQgPgfgEgQQgBgDgEAAQgEABABADQABAfAJAbQAPA1AAA2QAABMgVCPQgBADAEABQADABABgDQAfhaAIhwQAEg7gHgfIAAAA").cp();
	this.shape_79.setTransform(49.8,-11.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,85,85,0.467)").s().p("ABiAXQgBAAhhgWQg8gLgggWQgEgDgDAEQgCAEADADQANAOAVAKQAMAEAcAKQAmANAVAEQAiAHAdgHQADAAAAgEQAAgDgDgBIAAAA").cp();
	this.shape_80.setTransform(4.8,38.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,85,85,0.467)").s().p("AFhkRQgHgNAAgfQAAgLALgJQAJgIAKAAQAZAAAeCFQAQBCAKBFQAAClhfCEQhBBZhHAlIgNgCQAAgBgCgCQgCgDAAgGQAAgKAbgxQAwhXALgUQBTiigJhYQgrAzhqAhQhrAhh1AAQiMAAiUg7QikhEAAhZQAAgQAHgDQAFABAdAkQAlAoAsAWQAxAYBPAPQBOAOBNAAQCnAACAhFQBzg/AAg/QAAgOgGgOIAAAA").cp();
	this.shape_81.setTransform(8.1,-1.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,85,85,0.467)").s().p("AE9CLQg8AOgfAEQgxAFgsgIQhXgQhxhDQhcg3gzhOQgkg2gSgbQgfgxgRglQgCgFgFABQgGABgBAEQgFAVAFAXQAEARALAaQAIASAQAlQAOAgAMAWQAbAxAqAqQAlAmA1AjQBxBMB3AVQAiAGAWAAQAeAAAYgKQAWgJAYgWQAOgNAagbQAFgFgEgGQgDgGgHACIAAAA").cp();
	this.shape_82.setTransform(-2.9,19);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,85,85,0.467)").s().p("AAKgZQgMAGgJAOQgOATAGAJQAEAFAHgBQAFgBAEgHQAFgKADgDQAHgKAFgNQACgFgEgDQgEgCgFACIAAAA").cp();
	this.shape_83.setTransform(53.9,-26.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(255,85,85,0.467)").s().p("ACmifQAAgFgFABQgEABgBAEQgHBcgVBNQgJAigXAcQgTAYghAYQgkAbgpgKQgngJgighQgfgfgIg0QgDg7gEggQgBgDgDgBQgEgBAAAEQgKA7ADAhQAFAuAdAoQAbAkAnARQApASApgJQAjgHAigjQAcgcAUgnQALgTAGggQAHgjADgQQAPhCgIgrIAAAA").cp();
	this.shape_84.setTransform(20.3,15.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,85,85,0.467)").s().p("AAZhFQgHgDgDAGQgKAUgIArIgIAeQgBADgHAOQgFANABAEQgBgCgCAAQgCAAgBACQgCAIAJACQADAAABgBQARgWAKgqQARg6AEgIQACgGgHgDIAAAA").cp();
	this.shape_85.setTransform(19.3,35.6);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,85,85,0.467)").s().p("AAHAjQADAVADAMQABACADAAQACAAABgCQAJgggHgmQgDgOgJgTQgCgFgJgLQgKgKgCgGQgBgCgCAAQgDAAgBACIgDAHQgCADACAEQAVAdAEAZQACAJADAZIAAAA").cp();
	this.shape_86.setTransform(24.3,-1.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,85,85,0.467)").s().p("AAYgUQgegtgnACQgJABgBAIQgCAJAJACQAfAFAZAmQAQATAZArQACAEADgCQAEgBgBgEQgGgrgbgkIAAAA").cp();
	this.shape_87.setTransform(-42.2,-16.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,85,85,0.467)").s().p("AgYAFQAeAwAHAKQAZAhAZAOQAEACACgDQADgDgCgEQgKgUgSgZQgVgdgKgPQgXgegOgVQgagoAFgTQACgIgIgEQgIgDgEAHQgNAUAUAnQAFAKAdApIAAAA").cp();
	this.shape_88.setTransform(-42,3.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,85,85,0.467)").s().p("AF+hzQgBgFgFAAQgFAAgBAFQgPAogfAcQgVATgxAcQhoA4hdAaQhnAciGgWQgngHg/gaQhHgdgdgIQgBAAAAABQgBABABABQDqCUD3hHQAugOA5gcQAegPBDgmQArgXAUgXQAegigJgmIAAAA").cp();
	this.shape_89.setTransform(7.4,-14.1);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("ABehrQgSBjgcAwQghA7gxAAQgNAAgWgHQgUgHgEAAIgBgBQAFAHANAGQATAJAYAAQAFAAAMACQAJAAAAgGQAAgBANgFQATgJAPgRQAyg3AFh2QAAgDgBgBIAAAA").cp();
	this.shape_90.setTransform(21.1,14.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AARgKQAAAJgJAIQgIAJgIADQgJADAAgDQAAgCAGgEQAJgIACgFQAHgFAEgHQACgHABAAQACgBABADQABADgBAEIAAAA").cp();
	this.shape_91.setTransform(53.4,-28.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("Ag0iJQALAXAJAuQAFAbAKA2QAUBnAxAWIABAAQg1gzgNhhQgJg+gCgJQgIgkgSgTIgCgB").cp();
	this.shape_92.setTransform(-34,-0.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AghBFIAAACQAbgYAVgrQAagvgJgbQgFAQgCASQgFAVgXAtQgHAOgGAHQgJAJgIAJIAAAA").cp();
	this.shape_93.setTransform(20.3,35.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgJg0IgIgPIgDgFQAAAAACAAQACABACACQAFADAGAKQADAJAHANIAFAOIAGAWIADAwQgBAXgCAAQgDAAgBgXIgFguIgGgVIgMgj").cp();
	this.shape_94.setTransform(25.4,-2.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AEPAlQh8BDiJAAQiNAAhHgTQhxgfhWheIgHgHQBHBqCNAkQBLATCDAAQCOAAB7hFQB+hFAJhZQgOBVh9BBIAAAA").cp();
	this.shape_95.setTransform(3.6,-16.6);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgsgNQAAAAAHAAQARAAAZgOQAagPADAAQgCAfgHAhQgFAgAAADIABABQADgEADgOQAIgbAKhGQgPAFgFACQgbAPgqAUQAAABAAABIAAAA").cp();
	this.shape_96.setTransform(31.3,6);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#7F1C2D").s().p("AAmgSQgCATgEAOQgEAagFANIhBhJQAMADAagNQAXgMAKgKQAKABADgCIgEAi").cp();
	this.shape_97.setTransform(31,6.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("ACWiLQgZCQglA/QglA/g7AAQgwAAgngpQg2g4AJhqQCIAAAvgSQAegLA0ghQhIAZgyAOQhdAag6gMIgBA3QAABiBGAsQAjAXAkACQBDAAAqhKQAmhEALiBIAAgJ").cp();
	this.shape_98.setTransform(20.5,15.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#7F1C2D").s().p("AB6iEQgFADgKAHQgKAIgFACQgJAFgaAHQgYAIgLAFQgZAIgLADQgSADgYAAIhagBQgJBnA6BCQAhAoAvADQAsACAngiQAagaASgwQAJgVASg/QAKg5ABgcIgaAF").cp();
	this.shape_99.setTransform(20.7,14.9);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgSgEIACgDQAAgBABAAIAAAAQAAABALAAQALACAIALQgFAFgKAAQgIAAgHgGQgGgFgBgEIgCACQACAJgBAJQACAEAVAAQAMAAANgKQgFgPgIgIQgFgGgDAAQgNAAgFAFQgEAGgBABIABAD").cp();
	this.shape_100.setTransform(2.5,27.9);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgQgEQAAgKAXAAIAFAFQAKAJAAAJQgIAIgOgCQgQgCAAgNQgDAAgBAAQgBAAAAgEIAFAA").cp();
	this.shape_101.setTransform(2.3,27.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgjgGQgDABgBABQgCABAAAFQAAARAWAFQALADAKAAQAXAAAKgIQAHgHAAgMQAAgKgHgIQgFgIgGAAQghAAgIAEQgEAFgIAEIABACQACgBAHgDQAJgDAGAAQAYAAAGADQAGAEAAAMQAAARgnAAQgaAAAAgYIgCAA").cp();
	this.shape_102.setTransform(-1,21.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgfgGQgOAGAPALQAOALAKAAQAhAAAKgKQADgLgDgIQgDgKgHgEQgVgBgKABQgWABAAAJIgFAF").cp();
	this.shape_103.setTransform(-1.1,21.5);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AAmAWQgRAEgKAAQgmAAgKgOQgEgUgEgNIgBgDIgCAKQAAAdANAKQAOAKAoAAQAWAAAFgIQADgDAAgPQAAgagHgHQgJgKglAAQgIAAgMADQgLADgGAEIAAAAQABAAAIgCQAKgCAGAAQAoAAAJAJQAGAGAAAXQAAAKgBACIAAAA").cp();
	this.shape_104.setTransform(-4.1,13.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AABgeQgigDgHAKIgFAAQAAAXAEAIQAGAQAUAGQAIAAAWACQAWAAAGgHQADgGgBgQQgCgQAAgFQgIgIgigEIAAAA").cp();
	this.shape_105.setTransform(-4.2,13.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AH/iLQAADYimC8QhBBKhIAuQhEArgrAAQhVAAhuhJQgzghiZh7QhahIgyhBQhHhbAAhXQAAhGA6hBQBAhJCphrQi9BnhGBZQguA8AABEQAAA6BCBfQA/BcBjBdQBoBhBlA6QBvBCBRAAQAxAABIguQBLgvBDhOQCnjBAAjhQAAiHhkhRQhvhajUAAQi2AKgkAFIgRAEIgIgDQgEgBAAAFIAAgDQAAABAAADIAEAAQAcAACNgKQDiAAB1A+QCJBJAACiIAAAA").cp();
	this.shape_106.setTransform(1.9,0.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#B51C2E").s().p("ADFmyQiegNi0AXIhQgFQhuBEg1AnQheBEgcBLQgZA/AVBGQARA4AvA7QAyBABQBEQA1AuBcBDQBSA+AwAZQBOAqBGgEQCEgMB2ieQBfiBAriFQA4irhAhzQgphEhXgpQhFgghdgOIAAAA").cp();
	this.shape_107.setTransform(1.8,-0.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AhEgkQAVgMASAAQAuAAAUAUQANANAAAPQAAAQgLAPQgPATgYAAQgIAAgIgJQAAgBgLgRIgBgBQgCAEAAAJQAAAOAOAJQALAHALAAQAbAAATgWQASgUAAgXQAAgYgWgTQgXgVggAAQgxAHgNARIABAE").cp();
	this.shape_108.setTransform(51,-28.4);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#B51C2E").s().p("AgYAVIgog6QAFgUAyAAQAcAAAVAPQAZARAAAaQAAAogrANQgqAOgEgvIAAAA").cp();
	this.shape_109.setTransform(50.6,-28.3);

	this.addChild(this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-50.9,-44.7,109,89.6);
p.frameBounds = [rect];


(lib.head = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.eyebrow2();
	this.instance.setTransform(32.1,-9.7);

	this.instance_1 = new lib.eyebrow1();
	this.instance_1.setTransform(-4,-6.1);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("rgba(255,85,85,0.467)").s().p("AgMifQgCgBgBACQgEAFACAIQABAEAEAJQAXA9gCAwQgCAqgMAwQgQA1gYAgQgCACACADQABADAEAAQAzgDAfiFQALgugNg1QgPg6glgaIAAAA").cp();
	this.shape_110.setTransform(42.6,3.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#14263F").s().p("AAPgOQABgRgFgNQgEgJgIgRQgEgGgGACQgGACgBAHQgBAIADARQADAQgBAKQgCANABAWQACAfAAAGQABALAMAFQACACAFgCQAMgFAAgLQAAgLgCgaQgCgWAAgNIAAAA").cp();
	this.shape_111.setTransform(-41.7,-1.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("rgba(255,85,85,0.467)").s().p("AA3gbQgQgBgSAHQgIADgVAKQgVAJgJAAQgJgBgJAGQgGAEABAIQACAJAIgBQAHAAAOACQAGABAJgEQAGgCAIgEQAngSAWgQQAEgDgCgFQgDgEgEAAIAAAA").cp();
	this.shape_112.setTransform(23,22.3);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("rgba(255,85,85,0.467)").s().p("AAtggQgCgFgFgCQgGgBgEAEQgGAFgHASQgGAOgIAFQgLAJgVgNQgGgCgEADQgHAHADAJQADAJAIAFQAOALAXgFQAWgEANgYQANgVgGgWIAAAA").cp();
	this.shape_113.setTransform(35.5,3.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("rgba(255,85,85,0.467)").s().p("ABPgjQgDgDgEACQgMAEgPAOQgTARgGACQgUANgagQQgegYgOgGQgEgCgEADQgEACACAFQALAZAYASQAZATAbAAQAaAAAYgWQAYgTABgaQAAgEgDgCIAAAA").cp();
	this.shape_114.setTransform(-2.9,16.6);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#14263F").s().p("AAqgjQAFgQgNgMQgNgMgRAJQgSAHgJAEQgQAGgGAQQgCAGAAAMQgBAHABAKQAAAOAJAkQACAKAKAFQAJAFALgCQAUgEAPgOQAOgOAEgWQAFgegKgVIAAAA").cp();
	this.shape_115.setTransform(19.9,15.8);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#14263F").s().p("AA/g/QAAAOgjAxQgjA0gSAAQAAAAgHAMQgKAMgOADIgDgBIgDgEQANg7AkglQAJgJA5gvQAKAGAAAJIAAAA").cp();
	this.shape_116.setTransform(-33.2,-0.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#14263F").s().p("AAbAAQgBgagCgLQgEgXgLgHQgJgGgGADQgEAAgDABQgIAFgDAKQgCADAAAFQACAxAAACQACAfAFAWQABAGAGACQACAEAFACQADABAFgDQAQgIAEgYQACgNAAgZIAAAA").cp();
	this.shape_117.setTransform(-41.6,-1.8);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("rgba(255,85,85,0.467)").s().p("AAWgIQgIAIgFABQgJAGgMABQgQABgEgJQgBAAgCAAQgDAAAAAAQgEANANAFQAMAGARgDQAsgIgEgfQgBgCgBAAQgCgBgBABQgFADgIAJIAAAA").cp();
	this.shape_118.setTransform(35.8,6);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("rgba(255,85,85,0.467)").s().p("AApgLQgXALgOAAQgeAAgOgMQgCgCgCACQgDABACADQAMATAhADQAQACANgFQARgGABgLQAAgDgCgBQgCgCgCABIAAAA").cp();
	this.shape_119.setTransform(-2.7,21.6);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("rgba(255,85,85,0.467)").s().p("AAagIQAFAegJAaQgKAcgUACQgEABAAADQAAADAEABQAfADANgpQALghgHghQgHghgYgWQgbgagXAfQgCACACACQACACADgBQAZgOAQATQAQARAFAhIAAAA").cp();
	this.shape_120.setTransform(-41.4,-2.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("rgba(255,85,85,0.467)").s().p("ABJg5QAAAJgLANQgMAOgJAAQgKAAgGALQgFAIAAACQAAAGgHAAQgKgBgEAAQABAIgMAkQgNAmgHAIIgDACQgBAAAAgGQAOgiAAgBQAAgtgKgeQgNgpgbgIQADgGACgCQACgEAFAAQAeAPABAAQAEAAAPgGQANgFAMAAQAJAAAagTQAXgIAAAuIAAAA").cp();
	this.shape_121.setTransform(-36.3,-3.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("rgba(255,85,85,0.467)").s().p("AEAAYQhAgqhGgNQg7gLhWAIQhLAHhCAUQggAHgQACQgbAHgRAPQgFAFAFAGQAEAFAGgDQAQgKAcgEQAPgBAfgDQAZgDAygJQAtgHAfgBQAugEAhABQAqABAlAIQAKADAoAQQAeAMAUABQAFAAABgFQABgFgEgDIAAAA").cp();
	this.shape_122.setTransform(0.8,-24.6);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("rgba(255,85,85,0.467)").s().p("AEKgQQgagxhXgJQhEgIgigDQg4gGgsAAQg4ACgpAGQgSADgXALQgZANgNAFQgQADgJADIgFACIgFAAQgHABgCAEQgCAEACAFQgIAPAFAOQAFAQARACQApAHBwAiQBeAcA5ADQBFADAlgEQA/gHAjgcQAQgNABgVQABgTgKgRIAAAA").cp();
	this.shape_123.setTransform(2.9,-19.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("rgba(255,85,85,0.467)").s().p("AgEiMQgBgDgDABQgDAAAAADQACAYAHA5QAFA1ABAcQADBBgfAnQgEAEAAACQgCACAAAEQABADACABQABABACgBIADgCQABAAAAgBQABABAAABQABADAPgLQAJgIAIgSQAEgJAGgWQANgugMhAQgJg0gUg3IAAAA").cp();
	this.shape_124.setTransform(-26.8,2.4);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("rgba(255,85,85,0.467)").s().p("AgPh1Qggg0gjgWQgDgCgBADQgCACACACQA2A9AsBrQAfBFAMAoQADAMAEAmQACAfAJARQACAEAFgBQAFgBABgEQAHgxgUg/QgLghghhGQgcg9gQgcIAAAA").cp();
	this.shape_125.setTransform(14.2,-11.1);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("rgba(255,85,85,0.467)").s().p("ABPgsQAAgDgDAAQgDAAgBADQgOAsgDAGQgPAZgegGQgUgEgYgKQgYgLgSgLQgCgBgBACQgCABABACQAMAXAjAQQAdANAfADQAfADAPgkQAMgcgGgfIAAAA").cp();
	this.shape_126.setTransform(-36.3,8.8);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("rgba(255,85,85,0.467)").s().p("ABVAbQgYgFgjAJQgBAAgiASQgfAPgEgGQgQgWgHgsQgGgzgDgVQgBgCgCAAQgCAAgBACQgHAjAHArQACAKAEAcQAFAYAKANQAMASAlgQIAugYQAdgOAWgGQACAAAAgCQAAgCgCAAIAAAA").cp();
	this.shape_127.setTransform(21.3,19.9);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("rgba(255,85,85,0.467)").s().p("AAmhWQgCgCgCABQgCACABADQAPAkAAAnQgBAvgcASQgbATgZgqQgSgegHgjQgBgEgEABQgDABgBADQgGArAaAqQAdAvArgUQArgTABg9QABg4ggghIAAAA").cp();
	this.shape_128.setTransform(34.6,1.4);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("rgba(255,85,85,0.467)").s().p("AB7haQgBgCgCABQgCABAAACQABA8ggAyQglA+g3gKQgwgJgig9QgbgugJg6QAAgEgFABQgEABAAAEQgGBHAnA8QArBDBDAEQBAAEAmhJQAkhFgag4IAAAA").cp();
	this.shape_129.setTransform(-3.3,14.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("rgba(255,85,85,0.467)").s().p("AAPgSQgkgNgeAGQgEABgBAFQAAAEAEACQAJAFAQAEQAIACASACQAUAFAhAWQACABACgBQABgBAAgBQACgbgsgQIAAAA").cp();
	this.shape_130.setTransform(36.7,-22.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AAGgVIACAAIAAAAIACABQABAAAAADIgBABQABAGgBABQAAAEgBADIgDAEQgDAGgGAJQgEAGgCAAQgCgBACgIQABgCAHgNQADgIABgJIAAgEIADAB").cp();
	this.shape_131.setTransform(24.5,24.5);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#B51C2E").s().p("AABAAQAAgDAAAAQAAgBgBAAQAAAEAAAFIABgF").cp();
	this.shape_132.setTransform(25.3,23);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AhSi5QBMBIAlBhQAfBLASB8IADADQADhigshrQgvh3hLgvIgCAA").cp();
	this.shape_133.setTransform(15.2,-11.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgThQIgGADQAAACgBADQgBADAAAFQAAALADAMIAAABQABgCABgcQABAAABgBQABgCAGAAQASAAAJAuQAEAYAAAXQAAAWgIAPQgDAGgHAKQgGgFgEgKQgFgKgBgKIgBAAQAAAAgBACQgBADAAAFQAAASAHAJQAGAHAGAAQAhAAgFhSQgGhRghAAQgGAAgCABIAAAA").cp();
	this.shape_134.setTransform(-41.5,-1.6);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#B51C2E").s().p("AATghQAFAxAAAKQgBApgXALQgKgFgEgLQgCgHAAgRIgGhOQgCgQABgHQACgOAMAAQAJAAAJAQQAHALADARIAAAA").cp();
	this.shape_135.setTransform(-41.7,-1.6);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AAUhGQgBAAAAAGQAAAAAEANQAEAQADAhQACAQAAANQAAAOgeAMQgbALgQgCQABACADADQAEAEAHAAQAXAAAXgPQAWgOAAgMQgNhOgJgWIAAAA").cp();
	this.shape_136.setTransform(21.1,16.3);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AA+ipQgGgDgPAAQiYAAAACvQAABGAvAxQAvAzBCAAQAfAAANgTQASgZAAhFQAAgygGgyQgKhCgQgqQgCgCAAADQADAuAPCEQAABEgFAUQgIAigcAAQg3AAgqgnQgxgtAAhMQAAg+ARgcQAggzBngUIACgB").cp();
	this.shape_137.setTransform(-37,-1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#B51C2E").s().p("AA+ilQgrgFgwAbQg5AegKAvQgKBKAHAmQALA4AvAdQA0AiAjACQA0ADAEhGQADg+gGg8QgGg3gQhFIgPgT").cp();
	this.shape_138.setTransform(-36.9,-1.4);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("Ag0hCQgRAPAAAjQAAAZgEgGQABACAUBMIAAABQACAEAAgKQAAgFgCgJIgJhYQAAgaAhgOQAbgKAjAAQAOAAAIAiQAIAaAAAQQAAAfgDAJQgDAJgKAEQgSAEgPAFQgcAIggARIgCAAQACAAAAABQAAAAAGAAQABAAA3gOQA5gXAAgyQAAgcgOgfQgMgdgKAAQhBAAgZAVIAAAA").cp();
	this.shape_139.setTransform(22,16.7);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#7F1C2D").s().p("AgPhNQgeAHgSANQgHAoAHAnQAKAjAAAXIAFAFQAZAAAKgFQALgCAZgQQAYgOANAAQAJgsgCgYQgFglgbgbQgZAAgZAHIAAAA").cp();
	this.shape_140.setTransform(22.1,16.9);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgZg5QgCACgCAMQgDANAAAHQAAApAIAXQALAbAXAAQANAAAGgMQAEgJAAgLQAAgXgSgiQgTgogVgGQARASAOAfQASAhAAAZQAAASgOAAQgcAAgGg2QAAg2AAgGIgBgB").cp();
	this.shape_141.setTransform(34.5,-3.3);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgYg2QgEAHAAANQAAAIAAAMQAAAjAHAQQAGAPAPAJQAPAKAJgOQAHgJgDgVQgCgSgGgKQgGgYgIgNQgKgTgUgHIAAAK").cp();
	this.shape_142.setTransform(34.4,-3.5);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("AAVhdQAQAOAOAXQAaAsAAAeQAAAvgdAXQgUAQgTAAQghAAgcglQgbglAAgsQAAhHAagYQgPAIgIAYQgKAaAAApQAAAtAbAmQAdApAnAAQAiAAAXgfQAUgcAAgkQAAhIg/gnQgBAAgBgBIAAAAAguhxQAAAAAAAAQgCAAgCABQABAAADgBIAAAA").cp();
	this.shape_143.setTransform(-2.6,5.5);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("Ag0hpQgLADgEALQgBABgEAWQgRA5ANAsQAMAoAjAZQAlAcAigXQAigYAGgqQAFgmgVglQgWgng1gYQgZgSgPALIgDAD").cp();
	this.shape_144.setTransform(-2.7,5.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgVhfQAVAFAYAhQAGAIAEAHQgFgKgGgKQgVgfgTgEIgEACAgjhJQgSASAAA5QAAA1AZAaQAPARANAAQAiAAANgdQAMgagJgoQAAgCgBgBQAAAsgWAZQgQATgLAAQgTAAgOgiQgMgdAAgXQAAhQAngHQgTACgKAKIAAAA").cp();
	this.shape_145.setTransform(34.5,-1.9);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#7F1C2D").s().p("AgIhUQgjAOgGAzQgGArARAjQAcA+AjgrQAPgSAIgbQAHgbgFgUQgihVgnAFIAPAK").cp();
	this.shape_146.setTransform(34.7,-2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AgkiKIAIgCQgNAAgLADQAIgCAIABIAAAAAghiRQAGADAbAIQAbAKAVANQBAAnAABIQAABHguAnQgfAagfAAQgyAAgkg/Qgeg1AAgrQAAgvATghQANgXASgIQgJADgIAGQgpAdAABZQAABDA0AwQApAmAfAAQAiAAAjgeQAwgpAAhLQAAhDgzgoQgpggg+gGIAAAA").cp();
	this.shape_147.setTransform(-2.8,7);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#7F1C2D").s().p("AgciKQgUAEgKADQgQAEgJAJQgZAZgGAwQgGAtAMAeQASA4AkAgQAtApAxgYQA0gWAShGQAThDgigxQgvg1hRgRIAFAF").cp();
	this.shape_148.setTransform(-2.7,6.8);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AlNj5QhwBMAAB9QAAAHAJAiQANApANARIALALQgKgLgJgTQgTglAAgrQAAiSCVhDQBagoBZAAQDVAACUBLQCuBYAAChQAABjh+BZQiEBcijAAQigAAiBhdQgtgggbghQAaA1AWAOQBQA0AzAVQBXAjBfAAQCnAACJhdQCJhbAAhwQAAiti4heQiUhMjGAAQiRAAhoBGIAAAAAmOAQIgJAAIAIAVQAAgKABgLIAAAA").cp();
	this.shape_149.setTransform(3.8,0.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#B51C2E").s().p("Ak5j8Qg3AmghA0QhPB8BVBkIAAgoIgFgFIAFAAQAIBAAWAzQAdBBBlAyQB4BAB9AAQCAAAB4hAQCihRAShyQAKhHgqhKQglg/hCgyQhhhOiogRQiOgShgASQg6ALg3AmIAAAA").cp();
	this.shape_150.setTransform(3.4,0.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AhsiIIAAAEQAFABAOAAQAIgBANAAQBdAAAjA7QAdAxAABvQAAATgDAGQgEAGgLAAQgXAAg1hSQg8hcgVgZIgCgBQADAFA1BsQA7BrAqAAQAXAAAKgPQAHgMAAgYQAAiXg5gpQgZgSgqgHQgQgChMgFIgBAB").cp();
	this.shape_151.setTransform(36.1,-12.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#B51C2E").s().p("AhAiEQAXAAAYAHQAJACAgALQApARARArQANAdAEA2QAAANAEAgQACAegGAPQgQAUgZgNQgRgKgRgWQgSgSgTgjQgXgqgNgSQgCgDgNgbQgLgVgJgJIgTg1QADAEANgCQAIgBAPgDIAAAA").cp();
	this.shape_152.setTransform(35.7,-12.7);

	this.addChild(this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-48.2,-31.9,96.7,64);
p.frameBounds = [rect];


(lib.gunarm = function() {
	this.initialize();

	// Layer 1
	this.instance_2 = new lib.gun();
	this.instance_2.setTransform(-17.1,-0.8,1,1,0,0,0,-29.9,-0.9);

	this.instance_3 = new lib.gunforearm();
	this.instance_3.setTransform(-42.3,-8.7,1,1,0,0,0,-11.9,-1.1);

	this.addChild(this.instance_3,this.instance_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-48.9,-25.7,98.4,51.8);
p.frameBounds = [rect];


(lib.energyring = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{},true);

	// Layer 1 copy
	this.instance_4 = new lib.innerringmove();
	this.instance_4.setTransform(-17.2,17.5,0.642,0.642);
	this.instance_4.alpha = 0.441;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleX:0.34,scaleY:0.34,x:-32,y:32.2,alpha:0},11).to({_off:true},1).wait(10));

	// Layer 1 copy 2
	this.instance_5 = new lib.innerringmove();

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:0.34,scaleY:0.34,x:-32,y:32.2,alpha:0},21).wait(1));

	// Layer 1
	this.instance_6 = new lib.innerringmove();
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(11).to({_off:false},0).to({scaleX:0.65,scaleY:0.65,x:-17,y:17.2,alpha:0.379},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-35.9,-9.8,65.3,33.8);
p.frameBounds = [rect, new cjs.Rectangle(-36.4,-8,63.3,33), new cjs.Rectangle(-37,-6.2,61.5,32.3), new cjs.Rectangle(-37.6,-4.3,59.6,31.4), new cjs.Rectangle(-38.2,-2.4,57.7,30.6), new cjs.Rectangle(-38.7,-0.6,55.8,29.9), new cjs.Rectangle(-39.3,1.2,53.9,29.1), new cjs.Rectangle(-39.8,3,52,28.4), new cjs.Rectangle(-40.4,4.9,50.1,27.6), new cjs.Rectangle(-41,6.7,48.3,26.8), new cjs.Rectangle(-41.5,8.6,46.4,26), new cjs.Rectangle(-42.1,-9.8,71.5,45.5), new cjs.Rectangle(-36.5,-7.8,63.1,32.5), new cjs.Rectangle(-37.2,-5.7,61,31.6), new cjs.Rectangle(-37.8,-3.6,58.9,30.8), new cjs.Rectangle(-38.4,-1.6,56.8,30), new cjs.Rectangle(-39,0.5,54.7,29.1), new cjs.Rectangle(-39.6,2.5,52.5,28.2), new cjs.Rectangle(-40.2,4.6,50.4,27.4), new cjs.Rectangle(-40.9,6.6,48.3,26.6), new cjs.Rectangle(-41.5,8.7,46.1,25.7), new cjs.Rectangle(-42.1,10.8,44.1,24.9)];


(lib.armhand = function() {
	this.initialize();

	// Layer 1
	this.instance_7 = new lib.hand();
	this.instance_7.setTransform(-9.3,-6.2,1,1,0,0,0,-9.4,-17.9);

	this.instance_8 = new lib.shoulder();
	this.instance_8.setTransform(10.7,-46.3,1,1,0,0,0,3,-3.4);

	this.instance_9 = new lib.forearm();
	this.instance_9.setTransform(5.3,-41.3,1,1,0,0,0,9.8,-19.4);

	this.addChild(this.instance_9,this.instance_8,this.instance_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-25.2,-52.3,50.9,95.5);
p.frameBounds = [rect];


(lib.gunnertron = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{RoboMoveUp:0,RoboForward:22,RoboMoveForward:27,RoboBackward:49,RoboMoveBackward:54,RoboDown:76,RoboMoveDown:82},true);

	// armhand
	this.instance_10 = new lib.armhand();
	this.instance_10.setTransform(-73.7,-14.5,1,1,0,0,0,11.5,-47.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({regX:11.4,scaleX:1,scaleY:0.95,skewX:-23.9,skewY:-22.3,y:0.7},11).to({regX:11.6,scaleX:1,scaleY:1.14,skewX:-6.9,skewY:-7.8,x:-70.9,y:-26.2},5).to({regX:11.5,scaleY:1,skewX:0,skewY:0,x:-73.6,y:-14.4},5).wait(1).to({regX:11.6,rotation:17.2,x:-62.5,y:-18.4},5).to({rotation:32.4,x:-63.6,y:-7.4},11).to({regX:11.5,regY:-47,scaleX:1,scaleY:1,rotation:17.1,x:-58.1,y:-22.9},5).to({regX:11.6,regY:-47.1,scaleX:1,scaleY:1,rotation:17.2,x:-62.5,y:-18.4},5).to({regX:11.5,rotation:0,x:-73.6,y:-14.4},1).to({regX:11.4,rotation:11.7,x:-79.6,y:-6.4},5).to({regX:11.3,regY:-47.2,rotation:19.7,x:-86.7,y:4.3},11).to({regX:11.4,regY:-47,scaleX:1,scaleY:1,rotation:4.1,x:-81.6,y:-7.6},5).to({regY:-47.1,scaleX:1,scaleY:1,rotation:11.7,x:-79.6,y:-6.4},5).to({regX:11.5,rotation:0,x:-73.6,y:-14.4},1).to({regX:11.6,regY:-47.2,scaleY:1.12,rotation:12.5,x:-71.5,y:-34.5},5).wait(1).to({regX:11.5,regY:-47.1,scaleY:1.18,rotation:8.8,x:-70.6,y:-41.4},9).to({regY:-47,scaleX:1,scaleY:1.14,rotation:10.8,x:-76.2,y:-37.3},5).to({regX:11.6,regY:-47.2,scaleX:1,scaleY:1.12,rotation:12.5,x:-71.5,y:-34.5},5).wait(1));

	// head
	this.instance_11 = new lib.head();
	this.instance_11.setTransform(-32.5,-43.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({scaleX:1.07,scaleY:1.04,y:-27.7},11).to({scaleX:0.97,scaleY:1.23,y:-65.1},5).to({scaleX:1,scaleY:1,y:-43.5},5).wait(1).to({regX:6,regY:20,x:-26.3,y:-23.4},0).to({regY:20.1,rotation:-2.5,x:-13.3,y:-22.4},5).to({scaleY:0.91,x:-14.3,y:-8.4},11).to({regY:20,scaleX:0.91,scaleY:1.26,rotation:-2.4,x:-13.9,y:-28.2},5).to({regY:20.1,scaleX:1,scaleY:1,rotation:-2.5,x:-13.3,y:-22.4},5).to({regY:20,rotation:0,x:-26.3,y:-23.4},1).to({regY:19.9,rotation:2.5,x:-39.3,y:-19.5},5).to({scaleX:1.06,scaleY:0.89,rotation:-1.8,x:-42.3,y:-7.4},11).to({regY:20,scaleX:0.9,scaleY:1.09,rotation:0.5,x:-38.6,y:-23.8},5).to({regY:19.9,scaleX:1,scaleY:1,rotation:2.5,x:-39.3,y:-19.5},5).to({regX:0,regY:0,rotation:0,x:-32.4,y:-43.5},1).to({scaleX:0.94,scaleY:1.34,y:-75.5},5).wait(1).to({scaleX:0.88,scaleY:1.47,y:-86.5},9).to({scaleX:1.04,scaleY:1.13,x:-33.4,y:-64.7},5).to({scaleX:0.94,scaleY:1.34,x:-32.4,y:-75.5},5).wait(1));

	// body
	this.instance_12 = new lib.body();
	this.instance_12.setTransform(-30.7,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({scaleX:1.1,scaleY:0.84,y:14.3},11).to({scaleX:0.92,scaleY:1.18,y:-5.5},5).to({scaleX:1,scaleY:1,y:2.1},5).wait(1).to({regX:13,regY:35,x:-17.6,y:37.1},0).to({rotation:6.2,x:-11.6},5).to({regY:34.9,scaleY:0.84,x:-13.8,y:41.6},11).to({regY:35,scaleX:0.93,scaleY:1.09,rotation:6.1,x:-12.4,y:37.8},5).to({scaleX:1,scaleY:1,rotation:6.2,x:-11.6,y:37.1},5).to({rotation:0,x:-17.6},1).to({regY:34.9,rotation:-3.5,x:-22.6,y:41.1},5).to({regX:12.8,scaleX:1.09,scaleY:0.89,rotation:-7.8,x:-21.7,y:42.1},11).to({regX:12.7,regY:34.8,scaleX:0.98,scaleY:1.07,rotation:-4.6,x:-22.4,y:41.5},5).to({regX:13,regY:34.9,scaleX:1,scaleY:1,rotation:-3.5,x:-22.6,y:41.1},5).to({regX:0,regY:0,rotation:0,x:-30.6,y:2.1},1).to({scaleX:0.97,scaleY:1.17,y:-11.2},5).wait(1).to({scaleX:0.93,scaleY:1.32,y:-18.2},9).to({scaleX:1.05,scaleY:1.2,y:-12.7},5).to({scaleX:0.97,scaleY:1.17,y:-11.2},5).wait(1));

	// butt
	this.instance_13 = new lib.butt();
	this.instance_13.setTransform(-20.2,41.1,1,1,8.5,0,0,0.2,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({regX:0.4,regY:-10,scaleX:1.16,scaleY:0.82,rotation:9.5,x:-20,y:44.1},11).to({regY:-9.9,scaleX:0.95,scaleY:1.2,x:-18.7,y:34.2},5).to({scaleX:1,scaleY:1,rotation:7.8,x:-20,y:41.1},5).wait(1).to({regX:0.2,rotation:8.5,x:-20.1},0).to({rotation:25.2},5).to({regY:-9.8,scaleY:0.86,x:-21.9,y:45.1},11).to({scaleX:0.92,scaleY:1.02,rotation:25.1,x:-19.8,y:40.5},5).to({regY:-9.9,scaleX:1,scaleY:1,rotation:25.2,x:-20.1,y:41.1},5).to({rotation:8.5},1).to({regX:0.3,rotation:-5.9,x:-20,y:41.2},5).to({regY:-10,scaleX:1.11,scaleY:0.83,rotation:-16.2,x:-19.4,y:46.4},11).to({scaleX:1.05,scaleY:0.93,rotation:-10.3,x:-19.8,y:43.4},5).to({regY:-9.9,scaleX:1,scaleY:1,rotation:-5.9,x:-20,y:41.2},5).to({regX:0.2,rotation:8.5,x:-20.1,y:41.1},1).to({regY:-9.8,scaleX:0.86,scaleY:1.22,rotation:4.8,x:-19.9,y:34.6},5).wait(1).to({regY:-9.9,scaleX:0.75,scaleY:1.5,x:-19.8,y:30.5},9).to({regX:0.3,scaleX:0.96,scaleY:1.21,y:32.8},5).to({regX:0.2,regY:-9.8,scaleX:0.86,scaleY:1.22,x:-19.9,y:34.6},5).wait(1));

	// gunarm
	this.instance_14 = new lib.gunarm();
	this.instance_14.setTransform(18.2,-18.1,1,1,-4.4,0,0,-43.4,-8.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({scaleY:0.92,rotation:0,skewX:2.7,skewY:2.3,y:2.4},11).to({scaleY:1.24,skewX:2.9,skewY:3.2,x:17.6,y:-28.4},5).to({scaleY:1,rotation:-4,skewX:0,skewY:0,x:18.2,y:-18},5).wait(1).to({rotation:-4.3},0).to({x:36.2,y:-12},5).to({regX:-43.4,rotation:-8.5,x:33.2,y:1.8},11).to({rotation:0.2,x:34.7,y:-19},5).to({regX:-43.3,rotation:-4.3,x:36.2,y:-12},5).to({x:18.2,y:-18},1).to({rotation:-0.1,x:12.2,y:-16},5).to({regX:-43.4,rotation:-6.8,x:11.1,y:-11},11).to({rotation:6,x:10.7,y:-18.8},5).to({regX:-43.3,rotation:-0.1,x:12.2,y:-16},5).to({rotation:-4.3,x:18.2,y:-18},1).to({regY:-8.9,rotation:-11,x:16.3,y:-36},5).wait(1).to({rotation:1.5,x:16.2,y:-46},9).to({rotation:-5.6,x:21.3,y:-38.3},5).to({rotation:-11,x:16.3,y:-36},5).wait(1));

	// energy
	this.instance_15 = new lib.energyring("synched",0);
	this.instance_15.setTransform(-19.2,70.8,1.121,2.091,0,-22.3,-29.1);
	this.instance_15.alpha = 0.879;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},22).wait(5).to({skewX:13,skewY:6.2,x:-32.1,y:67.8,_off:false},0).to({_off:true},22).wait(5).to({scaleX:1.01,skewX:-45.6,skewY:-49.2,x:-8.1,_off:false},0).to({_off:true},22).wait(26));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-110.5,-75.5,224,212.1);
p.frameBounds = [rect, new cjs.Rectangle(-110.7,-74.2,224.4,213.2), new cjs.Rectangle(-110.8,-72.9,224.8,214.3), new cjs.Rectangle(-110.9,-71.6,225.1,215.2), new cjs.Rectangle(-110.9,-70.2,225.4,216.3), new cjs.Rectangle(-110.8,-69,225.5,217.5), new cjs.Rectangle(-110.8,-67.6,225.7,218.5), new cjs.Rectangle(-110.7,-66.3,225.8,219.6), new cjs.Rectangle(-110.5,-64.9,225.7,220.6), new cjs.Rectangle(-110.2,-63.6,225.6,221.6), new cjs.Rectangle(-110,-62.3,225.5,222.6), new cjs.Rectangle(-109.5,-61,221.2,223.8), new cjs.Rectangle(-105.5,-69.8,217,208.3), new cjs.Rectangle(-109.3,-78.4,220.8,219.6), new cjs.Rectangle(-113.4,-87.2,224.8,231), new cjs.Rectangle(-117.9,-95.8,229.3,242.4), new cjs.Rectangle(-108.3,-104.5,219.7,253.9), new cjs.Rectangle(-107.2,-98.7,220,250.6), new cjs.Rectangle(-110.4,-92.9,224.3,247.5), new cjs.Rectangle(-113.3,-87.1,228.1,244.5), new cjs.Rectangle(-116.4,-81.3,232.2,241.4), new cjs.Rectangle(-110.5,-75.5,223.9,238.3), new cjs.Rectangle(-110.5,-75.5,224,151.3), new cjs.Rectangle(-113.5,-75.7,230.6,153), new cjs.Rectangle(-116.6,-75.9,237.3,154.6), new cjs.Rectangle(-119.4,-76,243.7,156.2), new cjs.Rectangle(-122.1,-76.2,250,157.6), new cjs.Rectangle(-124.6,-76.5,256.1,196.5), new cjs.Rectangle(-124.3,-75,255.7,196.9), new cjs.Rectangle(-126.3,-73.2,257.7,197), new cjs.Rectangle(-128.6,-71.5,259.9,197), new cjs.Rectangle(-130.6,-69.7,261.8,197.1), new cjs.Rectangle(-132.8,-68,264,197.4), new cjs.Rectangle(-134.7,-66.2,265.7,197.4), new cjs.Rectangle(-136.8,-64.4,267.8,197.6), new cjs.Rectangle(-138.9,-62.6,269.8,197.8), new cjs.Rectangle(-140.7,-61,271.5,197.8), new cjs.Rectangle(-142.7,-59.2,273.4,198), new cjs.Rectangle(-143.3,-57.6,273.6,201.6), new cjs.Rectangle(-138.4,-65.8,269.9,187.1), new cjs.Rectangle(-137.7,-73.9,270.3,197.4), new cjs.Rectangle(-136.8,-82,270.4,207.6), new cjs.Rectangle(-135.7,-90.1,270.2,217.8), new cjs.Rectangle(-119.9,-95.6,247.5,225.6), new cjs.Rectangle(-118.3,-91.8,246.7,223.7), new cjs.Rectangle(-119.2,-87.9,248.5,222.1), new cjs.Rectangle(-120.1,-84,250.2,220.4), new cjs.Rectangle(-121,-80.2,251.9,218.7), new cjs.Rectangle(-124.6,-76.5,256.1,217.1), new cjs.Rectangle(-110.5,-75.5,224,151.3), new cjs.Rectangle(-115.3,-75,227.9,153), new cjs.Rectangle(-119.9,-74.7,231.7,154.5), new cjs.Rectangle(-125,-74.4,235.9,156), new cjs.Rectangle(-129.4,-74,239.4,157.2), new cjs.Rectangle(-134,-73.7,239.3,204), new cjs.Rectangle(-133.9,-72.1,239.3,204.4), new cjs.Rectangle(-135.6,-70.7,241.3,205), new cjs.Rectangle(-137.4,-69.4,243.4,205.6), new cjs.Rectangle(-139.2,-68,245.4,206.2), new cjs.Rectangle(-141,-66.7,247.5,207), new cjs.Rectangle(-142.7,-65.2,249.4,207.4), new cjs.Rectangle(-144.4,-63.7,251.3,207.9), new cjs.Rectangle(-146,-62.4,253,208.6), new cjs.Rectangle(-147.7,-61,255,209.2), new cjs.Rectangle(-149.4,-59.7,256.9,209.8), new cjs.Rectangle(-151.7,-55,259.3,207.2), new cjs.Rectangle(-148.2,-61.4,257,193.3), new cjs.Rectangle(-147.5,-67.5,257.1,201.6), new cjs.Rectangle(-146.5,-73.6,256.7,209.9), new cjs.Rectangle(-145.3,-79.4,256,218.1), new cjs.Rectangle(-124.8,-81.2,229.7,222.2), new cjs.Rectangle(-126,-79.5,232.3,222.6), new cjs.Rectangle(-128,-78.1,235.4,223.5), new cjs.Rectangle(-129.9,-76.5,238.5,224.3), new cjs.Rectangle(-131.8,-75.2,241.4,225.2), new cjs.Rectangle(-134,-73.7,239.3,225.9), new cjs.Rectangle(-110.5,-75.5,224,151.3), new cjs.Rectangle(-114.2,-84.1,228,160.7), new cjs.Rectangle(-117.8,-92.7,231.8,170.1), new cjs.Rectangle(-121.5,-101.3,235.8,179.6), new cjs.Rectangle(-125.4,-109.9,239.9,189), rect=new cjs.Rectangle(-129.5,-118.5,243.6,192.2), rect, new cjs.Rectangle(-127.4,-120.2,242.3,194.5), new cjs.Rectangle(-127.3,-121.8,243,196.9), new cjs.Rectangle(-127.3,-123.5,243.7,199.1), new cjs.Rectangle(-127.2,-125.2,244.2,201.5), new cjs.Rectangle(-127.3,-126.8,244.9,203.7), new cjs.Rectangle(-127.2,-128.5,245.3,206), new cjs.Rectangle(-127.1,-130.2,245.7,208.3), new cjs.Rectangle(-127.1,-131.8,246,210.5), new cjs.Rectangle(-123.4,-133.5,232.8,211.7), new cjs.Rectangle(-123.3,-127,234.6,204), new cjs.Rectangle(-125.2,-120.5,238.3,196.4), new cjs.Rectangle(-127.1,-114,242,188.7), new cjs.Rectangle(-128.5,-107.5,245.2,181.1), new cjs.Rectangle(-131.7,-101,248.8,173.1), new cjs.Rectangle(-129.3,-104.5,246,177.1), new cjs.Rectangle(-128.8,-108,245,181), new cjs.Rectangle(-128.6,-111.5,244.4,184.9), new cjs.Rectangle(-128.1,-115,243.3,188.9), new cjs.Rectangle(-129.5,-118.5,243.6,192.2)];

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;