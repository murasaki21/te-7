# Performance Tests

A framework for building simple tests to compare the performance of different versions of the EaselJS library.

More tests and framework features will be added over time.

Currently undocumented. Examine the source of "sprites.html" test to learn how to write new tests.